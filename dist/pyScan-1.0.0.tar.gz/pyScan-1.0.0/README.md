# SM Hackathon Project 2018

Input part for the Handwriting Digitizer project in SMHack, this will pass in 1120x800 processed
image into a neural net on the other ends and process it into a doc or image
 
##### CREDIT TO ADRIAN, PYIMAGESEARCH FOR SOME OF THE IMAGE TRANSFORMATION CODE: https://www.pyimagesearch.com/2014/08/25/4-point-opencv-getperspective-transform-example/